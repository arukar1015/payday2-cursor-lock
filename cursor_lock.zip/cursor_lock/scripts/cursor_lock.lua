- ===========================================================================
-- CursorLock  v1.0.0
-- Heist 中のみマウスカーソルをモニター中央に固定する SuperBLT mod
-- ===========================================================================

local ffi = require("ffi")

ffi.cdef[[
    /* --- カーソル位置 --- */
    int  SetCursorPos(int X, int Y);

    /* --- カーソルをクリップ領域に拘束 / 解除 --- */
    typedef struct { int left; int top; int right; int bottom; } RECT;
    int  ClipCursor(const RECT* lpRect);

    /* --- スクリーンサイズ取得 --- */
    int  GetSystemMetrics(int nIndex);
]]

local SM_CXSCREEN = 0   -- プライマリモニター幅
local SM_CYSCREEN = 1   -- プライマリモニター高さ

-- 現在 Heist 中かどうかを返すヘルパー
local function is_in_heist()
    if not game_state_machine then return false end
    local s = game_state_machine:current_state_name()
    return s == "ingame_waiting_for_players"
        or s == "ingame_playing"
        or s == "ingame_assault"
        or s == "ingame_stealth"
end

-- カーソルを中央に移動させ、ClipCursor で 1px の矩形に拘束する
local function lock_cursor()
    local w = ffi.C.GetSystemMetrics(SM_CXSCREEN)
    local h = ffi.C.GetSystemMetrics(SM_CYSCREEN)
    local cx = math.floor(w / 2)
    local cy = math.floor(h / 2)

    -- まず中央へ移動
    ffi.C.SetCursorPos(cx, cy)

    -- ClipCursor で 1×1 px に拘束（最も確実な方法）
    local rect = ffi.new("RECT", { cx, cy, cx + 1, cy + 1 })
    ffi.C.ClipCursor(rect)
end

-- カーソル拘束を解除する
local function unlock_cursor()
    ffi.C.ClipCursor(nil)   -- NULL を渡すと制限解除
end

-- --------------------------------------------------------
-- GameSetup.init の PostHook でゲーム起動直後に登録
-- --------------------------------------------------------
Hooks:PostHook(GameSetup, "init", "CursorLock_Init", function(self)
    log("[CursorLock] GameSetup init")
end)

-- --------------------------------------------------------
-- GameSetup.update を毎フレーム監視
--   * Heist に入ったら lock
--   * Heist を抜けたら unlock
-- --------------------------------------------------------
local _was_in_heist = false

Hooks:PostHook(GameSetup, "update", "CursorLock_Update", function(self, t, dt)
    local in_heist = is_in_heist()

    if in_heist and not _was_in_heist then
        log("[CursorLock] Heist start → カーソルをロック")
        lock_cursor()
        _was_in_heist = true

    elseif not in_heist and _was_in_heist then
        log("[CursorLock] Heist end → カーソルのロックを解除")
        unlock_cursor()
        _was_in_heist = false
    end
end)

-- --------------------------------------------------------
-- ゲーム終了時にも必ず解除（万一のため）
-- --------------------------------------------------------
Hooks:PostHook(GameSetup, "close", "CursorLock_Close", function(self)
    unlock_cursor()
    log("[CursorLock] GameSetup close → カーソルのロックを解除")
end)

log("[CursorLock] スクリプトロード完了")
